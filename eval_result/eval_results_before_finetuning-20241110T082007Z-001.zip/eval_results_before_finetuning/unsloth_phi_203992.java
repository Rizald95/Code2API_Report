Title: How do I remove repeated elements from ArrayList?
Question: 
                
I have an ArrayList<String>, and I want to remove repeated strings from it. How can I do this?
    
Answer: 
If you don't want duplicates in a Collection, you should consider why you're using a Collection that allows duplicates. The easiest way to remove repeated elements is to add the contents to a Set (which will not allow duplicates) and then add the Set back to the ArrayList:

Set<String> set = new HashSet<>(yourList);
yourList.clear();
yourList.addAll(set);


Of course, this destroys the ordering of the elements in the ArrayList.
    
Code: Set<String> set = new HashSet<>(yourList);
yourList.clear();
yourList.addAll(set);

Complete the code as a full Java method.

Here's a complete method that takes an ArrayList<String> as input and returns a new ArrayList<String> with duplicates removed:

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class RemoveDuplicates {

    public static ArrayList<String> removeDuplicates(ArrayList<String> inputList) {
        Set<String> set = new HashSet<>(inputList);
        inputList.clear();
        inputList.addAll(set);
        return inputList;
    }

    public static void main(String[] args) {
