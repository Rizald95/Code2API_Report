Title: How to initailize byte array of 100 bytes in java with all 0's
Question: 
                
How to initialize byte array of 100 bytes in java with all 0's.
I want to create 100 byte array and initialize it with all 0's
    
Answer: 
A new byte array will automatically be initialized with all zeroes. You don't have to do anything.

The more general approach to initializing with other values, is to use the Arrays class.

import java.util.Arrays;

byte[] bytes = new byte[100];
Arrays.fill( bytes, (byte) 1 );

    
Code: import java.util.Arrays;

byte[] bytes = new byte[100];
Arrays.fill( bytes, (byte) 1 );

Complete the code as a full Java method.

# Answer

You can create a full Java method as follows:

    import java.util.Arrays;

    public class Main {
      public static void main(String args[]) {
        byte[] bytes = newOrig();
        System.out.println(Arrays.toString(bytes));
      }
  
      public static byte[] newOrig() {
        byte[] bytes = new byte[100];
        Arrays.fill( bytes, (byte) 1 );
        return bytes;
      }
    }

You can try this method online here: https://ideone.com/v1Kv0i
