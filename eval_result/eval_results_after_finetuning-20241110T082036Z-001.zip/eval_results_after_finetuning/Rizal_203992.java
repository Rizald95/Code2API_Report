Title: How do I remove repeated elements from ArrayList?
Question: 
                
I have an ArrayList<String>, and I want to remove repeated strings from it. How can I do this?
    
Answer: 
If you don't want duplicates in a Collection, you should consider why you're using a Collection that allows duplicates. The easiest way to remove repeated elements is to add the contents to a Set (which will not allow duplicates) and then add the Set back to the ArrayList:

Set<String> set = new HashSet<>(yourList);
yourList.clear();
yourList.addAll(set);


Of course, this destroys the ordering of the elements in the ArrayList.
    
Code: Set<String> set = new HashSet<>(yourList);
yourList.clear();
yourList.addAll(set);

Complete the code as a full Java method.

# Answer
You can convert the code into a full Java method as follows:

    import java.util.ArrayList;
    import java.util.HashSet;
    import java.util.Set;
    
    public class Main {
    
        public static void main(String[] args) {
            ArrayList<String> myList = new ArrayList<String>();
            myList.add("A");
            myList.add("B");
            myList.add("A");
    
            System.out.println("myList = " + myList);
    
            removeDuplicates(myList);
    
            System.out.println("