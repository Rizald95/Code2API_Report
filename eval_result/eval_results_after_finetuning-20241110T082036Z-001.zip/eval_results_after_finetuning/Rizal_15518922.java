Title: How to validate URL in java using regex? [duplicate]
Question: 
                    
            
        
            
                
                    
                            
                                This question already has answers here:
                                
                            
                    
                
            
                    
                        What is the best regular expression to check if a string is a valid URL?
                            
                                (64 answers)
                            
                    
                Closed 10 years ago.
        


    

I want to validate url started with http/https/www/ftp and checks for /\ slashes and checks for .com,.org etc at the end of URL using regular expression. Is there any regex patttern for URL validation?
    
Answer: 
This works:

Pattern p = Pattern.compile("(@)?(href=')?(HREF=')?(HREF=\")?(href=\")?(http://)?[a-zA-Z_0-9\\-]+(\\.\\w[a-zA-Z_0-9\\-]+)+(/[#&\\n\\-=?\\+\\%/\\.\\w]+)?");  

    Matcher m = p.matcher("your url here"); 

    
Code: Pattern p = Pattern.compile("(@)?(href=')?(HREF=')?(HREF=\")?(href=\")?(http://)?[a-zA-Z_0-9\\-]+(\\.\\w[a-zA-Z_0-9\\-]+)+(/[#&\\n\\-=?\\+\\%/\\.\\w]+)?");  

    Matcher m = p.matcher("your url here"); 

Complete the code as a full Java method.

# Answer

You can use the Pattern and Matcher classes in Java to create a regular expression and search a string with it. Here is a full Java method that you can use to validate a URL with regular expression:

    import java.util.regex.*;

    public class RegexExample {
        public static void main(String[] args) {
            String test1 = "http://www.stackoverflow.com";
            String test2 = "ftp://www.stackoverflow.com";
            String test3 = "HREF=\"http://www.stackoverflow.com\"";
            String test4 = "HREF=\"ftp://www.stackoverflow.com\"";
            
            System