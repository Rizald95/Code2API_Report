Title: How can I get specific data element in a text file [closed]
Question: 
                    
            
        
            
                
                    
                            
                                Closed. This question needs details or clarity. It is not currently accepting answers.
                                
                            
                    
                
            
        
            
        
            
                
                        
                            
                        
                    Want to improve this question? Add details and clarify the problem by editing this post.
                
                    
                        Closed 7 years ago.
                    
                

                
            
        
            
                    
                        Improve this question
                    
            


    

I have a text file and two columns in it(name and birthday). And in first column I have two names(john and brayn). I only want to get name brayn and his birthday. How can I do this? 

my text file:

name  birthday
john    1991
brayn    1994

Below the code snippet that I tried:

import java.io.*;

class Detail{
    public static void main(String[] args) throws Exception {
        users u=new users();
        if(args.length==1){
            System.out.println("No Details");
        }else{
            FileReader reader = new FileReader("users.txt");
            BufferedReader buffer= new BufferedReader(reader);

            String line = null;

            while ((line = buffer.readLine()) != null) {
                u.addToSearchString(line+'\n');
            }
            buffer.close();
            u.printName();
            }
        }
} 

class users{

    String names;

    users(){
        names=new String();
    }

    void addToSearchString(String add){
        names += add;
    }

    void printName() {
        int i = 0;
        String splitter = "";
        String[] name_array = names.split(splitter);

        for (i = 0; i < name_array.length; i++) {
            System.out.println(name_array[i]);
        }
    }
}


    
Any help would be appreciated.
    
Answer: 
You can use the String.split() method.

String example = "name:brayn:age:1994";
String[] parts = example.split(":");
System.out.println(parts[1]);       //brayn
System.out.println(parts[3]);       //