import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexExample {

    public static void main(String[] args) {
        String input = "Print this";
        System.out.println(findWord(input));
   0bthis\\b"
            );
        m.find();
        System.out.println(m.group());
    }
}