Title: How to create a calendar object in Java
Question: 
                
I need to turn a Date object into a calendar in Java, and try to access its field value for HOUR_OF_DAY. Does anybody know how to do it?
    
Answer: 
Use the setTime method:

Date date = new Date();
Calendar calendar = Calendar.getInstance();
calendar.setTime(date);
int hourOfDay = calendar.get(Calendar.HOUR_OF_DAY);

    
Code: Date date = new Date();
Calendar calendar = Calendar.getInstance();
calendar.setTime(date);
int hourOfDay = calendar.get(Calendar.HOUR_OF_DAY);

Complete the code as a full Java method.

# Answer

You can create a full Java method as follows:

    import java.util.Date;
    import java.util.Calendar;
    
    public class Test {
    
        public static int getCurrentHourOfDay() {
            Date date = new Date();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            int hourOfDay = calendar.get(Calendar.HOUR_OF_DAY);
            return hourOfDay;
        }
    
        public static void main(String args[]) {
            System.out.println(getCurrentHourOfDay());
        }
    }

